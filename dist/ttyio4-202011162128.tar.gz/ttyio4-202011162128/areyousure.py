import sys
import ttyio4 as ttyio

sys.exit(ttyio.areyousure("are you sure?"))
